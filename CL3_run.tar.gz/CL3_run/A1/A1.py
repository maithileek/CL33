def partition(list_,left,right):
	piv=list_[left]
	i=left+1
	j=right
	while 1:
		while i<=j and list_[i]<=piv:
			i=i+1
		while i<=j and list_[j]>=piv:
			j=j-1
		if j<=i:
			break
		list_[i],list_[j]=list_[j],list_[i]
	list_[left],list_[j]=list_[j],list_[left]
	return j

def qs(list_,left,right):
	if right<=left:
		return
	piv=partition(list_,left,right)
	qs(list_,left,piv)
	qs(list_,piv+1,right)

def bs(data,key,l,h):
	mid=(h+l)/2
	if h>l:
		if data[mid]==key:
			print "Found at "+str(mid+1)+" position" 
			return
		elif data[mid]>key:
			bs(data,key,l,mid)
		elif data[mid]<key:
			bs(data,key,mid+1,h)
	else:
		print "Not Found."

f=open('mem.txt','r')
data=f.read()
a=[int(x) for x in data.split()]
qs(a,0,len(a)-1)
key=input("Enter Key:" )
bs(a,key,0,len(a)-1)
